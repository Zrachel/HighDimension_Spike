The demo is to reproduce the last figure in the paper. 

For new versions of T-MSBL, please check the link:
http://dsp.ucsd.edu/~zhilin/TSBL_code.zip